"""rauth shim for iOS."""

class OAuth2Service:
    def __init__(self, *a, **k):
        pass
    def get_authorize_url(self, *a, **k):
        return ""
    def get_auth_session(self, *a, **k):
        return None
    def get_access_token(self, *a, **k):
        return None
    def get_session(self, *a, **k):
        return None

class OAuth1Service:
    def __init__(self, *a, **k):
        pass
